create database cginversionesareas;

create table cginversiones.areas(
id_area int primary key not null auto_increment,
area varchar(100) not null
)engine InnoDB;

create table cginversiones.cargos(
id_cargo int primary key not null auto_increment,
cargo varchar(100) not null,
id_area int not null,
constraint fk_cargo_area foreign key (id_area) references cginversiones.areas(id_area)
)engine InnoDB;

create table cginversiones.usuarios(
id_usuario int primary key not null auto_increment,
nombre varchar(100) not null,
id_cargo int not null,
constraint fk_usuario_cargo foreign key (id_cargo) references cginversiones.cargos(id_cargo)
)engine InnoDB;

create table cginversiones.solicitudpresupuesto(
id_solicitud int primary key not null auto_increment,
id_usuario int not null,
fecha date not null,
estado int not null, -- { 0 = entregada, 1 = en proceso, 2= ,3 = pendiente (sin fondos)}
descripcion varchar(500) not null,
constraint fk_solicitud_usuario foreign key (id_usuario) references cginversiones.usuarios(id_usuario)
)engine InnoDB;

create table cginversiones.bancos(
id_banco int primary key not null auto_increment,
banco varchar(100) not null
)engine InnoDB;

create table cginversiones.cuentas(
id_cuenta int primary key not null auto_increment,
cuenta varchar(100) not null,
debe double not null,
haber double not null,
id_banco int not null,
constraint fk_cuenta_banco foreign key (id_banco) references cginversiones.bancos(id_banco)
)engine InnoDB;

create table cginversiones.movimientos(
id_movimiento int primary key not null auto_increment,
id_cuenta int not null,
tipo int not null, -- {0 = ingreso, 1 = egreso}
cuenta varchar(100) not null,
fecha date not null,
cantidad double not null,
constraint fk_movimiento_cuenta foreign key (id_cuenta) references cginversiones.cuentas(id_cuenta)
)engine InnoDB;

create table cginversiones.comprobantes(
id_comprobante int primary key not null auto_increment,
id_solicitud int not null,
id_movimiento int not null,
constraint fk_comprobante_solicitud foreign key (id_solicitud) references cginversiones.solicitudpresupuesto(id_solicitud),
constraint fk_comprobante_movimiento foreign key (id_movimiento) references cginversiones.movimientos(id_movimiento)
)engine InnoDB;

insert into cginversiones.areas values (0,'Departamento Financiero');
insert into cginversiones.cargos values (0,'Secretaria',1);
insert into cginversiones.usuarios values (0,'Anabelle',1);
insert into cginversiones.solicitudpresupuesto values (0,1,now(),0,'solicitud de compra de papelerias para impresoras');

