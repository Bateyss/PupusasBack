package com.cgi.inc;

import java.util.List;

public interface Dao<T> {

	public List<T> findAll();

	public T readById(Object id);

	public void create(T e);

	public void update(T e);

	public void delete(T e);
}
