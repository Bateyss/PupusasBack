package com.cgi.inc;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
	Connection con = null;
	private final String url = "jdbc:mysql://localhost:3306/cginversiones?useSSL=false";
	private final String user = "root";
	private final String pass = "root";

	public Conexion() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
			if (con != null) {
				System.out.println("Base de datos conectada");
			}
		} catch (Exception e) {
			System.out.println("Error al conectar con DB en " + this.getClass().getSimpleName());
		}
	}

	public Connection conectar() {
		return con;
	}

}
