package com.cgi.inc;

import java.util.List;

import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public abstract class AbsInc<T> {
	private Class<T> entity;
	protected Session ses;
	public AbsInc(Class<T> entit) {
		this.entity = entit;
	}
	public abstract SessionFactory getSessionFactory();
	public List<T> findAll(){
		ses = getSessionFactory().getCurrentSession();
		CriteriaQuery cq = ses.getCriteriaBuilder().createQuery();
		cq.select(cq.from(entity));
		return ses.createQuery(cq).getResultList();
	}
	public T readById(Object id) {
		ses = getSessionFactory().getCurrentSession();
		return ses.find(entity, id);
	}
	public void create(T e) {
		ses = getSessionFactory().getCurrentSession();
		ses.save(e);
	};
	public void update(T e) {
		ses = getSessionFactory().getCurrentSession();
		ses.update(e);
	};
	public void delete(T e) {
		ses = getSessionFactory().getCurrentSession();
		ses.delete(e);
	};
}
