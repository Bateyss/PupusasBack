package com.cgi.models;


import java.util.LinkedList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "bancos", catalog = "cginversiones")
public class Bancos implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idBanco;
	private String banco;
	private List<Cuentas> cuentases = new LinkedList<>();

	public Bancos() {
	}

	public Bancos(String banco) {
		this.banco = banco;
	}

	public Bancos(String banco, List<Cuentas> cuentases) {
		this.banco = banco;
		this.cuentases = cuentases;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id_banco", unique = true, nullable = false)
	public Integer getIdBanco() {
		return this.idBanco;
	}

	public void setIdBanco(Integer idBanco) {
		this.idBanco = idBanco;
	}

	@Column(name = "banco", nullable = false, length = 100)
	public String getBanco() {
		return this.banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bancos")
	public List<Cuentas> getCuentases() {
		return this.cuentases;
	}

	public void setCuentases(List<Cuentas> cuentases) {
		this.cuentases = cuentases;
	}

}
