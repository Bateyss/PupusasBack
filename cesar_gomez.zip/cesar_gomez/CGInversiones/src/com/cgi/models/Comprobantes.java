package com.cgi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "comprobantes", catalog = "cginversiones")
public class Comprobantes implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idComprobante;
	private Movimientos movimientos;
	private Solicitudpresupuesto solicitudpresupuesto;

	public Comprobantes() {
	}

	public Comprobantes(Movimientos movimientos, Solicitudpresupuesto solicitudpresupuesto) {
		this.movimientos = movimientos;
		this.solicitudpresupuesto = solicitudpresupuesto;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id_comprobante", unique = true, nullable = false)
	public Integer getIdComprobante() {
		return this.idComprobante;
	}

	public void setIdComprobante(Integer idComprobante) {
		this.idComprobante = idComprobante;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_movimiento", nullable = false)
	public Movimientos getMovimientos() {
		return this.movimientos;
	}

	public void setMovimientos(Movimientos movimientos) {
		this.movimientos = movimientos;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_solicitud", nullable = false)
	public Solicitudpresupuesto getSolicitudpresupuesto() {
		return this.solicitudpresupuesto;
	}

	public void setSolicitudpresupuesto(Solicitudpresupuesto solicitudpresupuesto) {
		this.solicitudpresupuesto = solicitudpresupuesto;
	}

}
