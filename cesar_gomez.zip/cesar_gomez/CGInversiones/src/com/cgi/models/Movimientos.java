package com.cgi.models;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "movimientos", catalog = "cginversiones")
public class Movimientos implements java.io.Serializable {


	private static final long serialVersionUID = 1L;
	private Integer idMovimiento;
	private Cuentas cuentas;
	private int tipo;
	private String cuenta;
	private Date fecha;
	private double cantidad;
	private List<Comprobantes> comprobanteses = new LinkedList<>();

	public Movimientos() {
	}

	public Movimientos(Cuentas cuentas, int tipo, String cuenta, Date fecha, double cantidad) {
		this.cuentas = cuentas;
		this.tipo = tipo;
		this.cuenta = cuenta;
		this.fecha = fecha;
		this.cantidad = cantidad;
	}

	public Movimientos(Cuentas cuentas, int tipo, String cuenta, Date fecha, double cantidad,
			List<Comprobantes> comprobanteses) {
		this.cuentas = cuentas;
		this.tipo = tipo;
		this.cuenta = cuenta;
		this.fecha = fecha;
		this.cantidad = cantidad;
		this.comprobanteses = comprobanteses;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id_movimiento", unique = true, nullable = false)
	public Integer getIdMovimiento() {
		return this.idMovimiento;
	}

	public void setIdMovimiento(Integer idMovimiento) {
		this.idMovimiento = idMovimiento;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_cuenta", nullable = false)
	public Cuentas getCuentas() {
		return this.cuentas;
	}

	public void setCuentas(Cuentas cuentas) {
		this.cuentas = cuentas;
	}

	@Column(name = "tipo", nullable = false)
	public int getTipo() {
		return this.tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	@Column(name = "cuenta", nullable = false, length = 100)
	public String getCuenta() {
		return this.cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha", nullable = false, length = 10)
	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	@Column(name = "cantidad", nullable = false, precision = 22, scale = 0)
	public double getCantidad() {
		return this.cantidad;
	}

	public void setCantidad(double cantidad) {
		this.cantidad = cantidad;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "movimientos")
	public List<Comprobantes> getComprobanteses() {
		return this.comprobanteses;
	}

	public void setComprobanteses(List<Comprobantes> comprobanteses) {
		this.comprobanteses = comprobanteses;
	}

}
