package com.cgi.models;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "cuentas", catalog = "cginversiones")
public class Cuentas implements java.io.Serializable {


	private static final long serialVersionUID = 1L;
	private Integer idCuenta;
	private Bancos bancos;
	private String cuenta;
	private double debe;
	private double haber;
	private List<Movimientos> movimientoses = new LinkedList<>();

	public Cuentas() {
	}

	public Cuentas(Bancos bancos, String cuenta, double debe, double haber) {
		this.bancos = bancos;
		this.cuenta = cuenta;
		this.debe = debe;
		this.haber = haber;
	}

	public Cuentas(Bancos bancos, String cuenta, double debe, double haber, List<Movimientos> movimientoses) {
		this.bancos = bancos;
		this.cuenta = cuenta;
		this.debe = debe;
		this.haber = haber;
		this.movimientoses = movimientoses;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id_cuenta", unique = true, nullable = false)
	public Integer getIdCuenta() {
		return this.idCuenta;
	}

	public void setIdCuenta(Integer idCuenta) {
		this.idCuenta = idCuenta;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_banco", nullable = false)
	public Bancos getBancos() {
		return this.bancos;
	}

	public void setBancos(Bancos bancos) {
		this.bancos = bancos;
	}

	@Column(name = "cuenta", nullable = false, length = 100)
	public String getCuenta() {
		return this.cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	@Column(name = "debe", nullable = false, precision = 22, scale = 0)
	public double getDebe() {
		return this.debe;
	}

	public void setDebe(double debe) {
		this.debe = debe;
	}

	@Column(name = "haber", nullable = false, precision = 22, scale = 0)
	public double getHaber() {
		return this.haber;
	}

	public void setHaber(double haber) {
		this.haber = haber;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "cuentas")
	public List<Movimientos> getMovimientoses() {
		return this.movimientoses;
	}

	public void setMovimientoses(List<Movimientos> movimientoses) {
		this.movimientoses = movimientoses;
	}

}
