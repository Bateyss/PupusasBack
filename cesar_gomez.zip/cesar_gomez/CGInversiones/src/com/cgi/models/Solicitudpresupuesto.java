package com.cgi.models;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "solicitudpresupuesto", catalog = "cginversiones")
public class Solicitudpresupuesto implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idSolicitud;
	private Usuarios usuarios;
	private Date fecha;
	private int estado;
	private String descripcion;
	private List<Comprobantes> comprobanteses = new LinkedList<>();

	public Solicitudpresupuesto() {
	}

	public Solicitudpresupuesto(Usuarios usuarios, Date fecha, int estado, String descripcion) {
		this.usuarios = usuarios;
		this.fecha = fecha;
		this.estado = estado;
		this.descripcion = descripcion;
	}

	public Solicitudpresupuesto(Usuarios usuarios, Date fecha, int estado, String descripcion,
			List<Comprobantes> comprobanteses) {
		this.usuarios = usuarios;
		this.fecha = fecha;
		this.estado = estado;
		this.descripcion = descripcion;
		this.comprobanteses = comprobanteses;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id_solicitud", unique = true, nullable = false)
	public Integer getIdSolicitud() {
		return this.idSolicitud;
	}

	public void setIdSolicitud(Integer idSolicitud) {
		this.idSolicitud = idSolicitud;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_usuario", nullable = false)
	public Usuarios getUsuarios() {
		return this.usuarios;
	}

	public void setUsuarios(Usuarios usuarios) {
		this.usuarios = usuarios;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha", nullable = false, length = 10)
	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	@Column(name = "estado", nullable = false)
	public int getEstado() {
		return this.estado;
	}

	public void setEstado(int estado) {
		this.estado = estado;
	}

	@Column(name = "descripcion", nullable = false, length = 500)
	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "solicitudpresupuesto")
	public List<Comprobantes> getComprobanteses() {
		return this.comprobanteses;
	}

	public void setComprobanteses(List<Comprobantes> comprobanteses) {
		this.comprobanteses = comprobanteses;
	}

}
