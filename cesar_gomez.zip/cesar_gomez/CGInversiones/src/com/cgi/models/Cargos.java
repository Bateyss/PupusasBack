package com.cgi.models;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "cargos", catalog = "cginversiones")
public class Cargos implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idCargo;
	private Areas areas;
	private String cargo;
	private List<Usuarios> usuarioses = new LinkedList<>();

	public Cargos() {
	}

	public Cargos(Areas areas, String cargo) {
		this.areas = areas;
		this.cargo = cargo;
	}

	public Cargos(Areas areas, String cargo, List<Usuarios> usuarioses) {
		this.areas = areas;
		this.cargo = cargo;
		this.usuarioses = usuarioses;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id_cargo", unique = true, nullable = false)
	public Integer getIdCargo() {
		return this.idCargo;
	}

	public void setIdCargo(Integer idCargo) {
		this.idCargo = idCargo;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_area", nullable = false)
	public Areas getAreas() {
		return this.areas;
	}

	public void setAreas(Areas areas) {
		this.areas = areas;
	}

	@Column(name = "cargo", nullable = false, length = 100)
	public String getCargo() {
		return this.cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "cargos")
	public List<Usuarios> getUsuarioses() {
		return this.usuarioses;
	}

	public void setUsuarioses(List<Usuarios> usuarioses) {
		this.usuarioses = usuarioses;
	}

}
