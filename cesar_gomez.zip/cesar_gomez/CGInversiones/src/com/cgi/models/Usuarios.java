package com.cgi.models;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "usuarios", catalog = "cginversiones")
public class Usuarios implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idUsuario;
	private Cargos cargos;
	private String nombre;
	private List<Solicitudpresupuesto> solicitudpresupuestos = new LinkedList<>();

	public Usuarios() {
	}

	public Usuarios(Cargos cargos, String nombre) {
		this.cargos = cargos;
		this.nombre = nombre;
	}

	public Usuarios(Cargos cargos, String nombre, List<Solicitudpresupuesto> solicitudpresupuestos) {
		this.cargos = cargos;
		this.nombre = nombre;
		this.solicitudpresupuestos = solicitudpresupuestos;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id_usuario", unique = true, nullable = false)
	public Integer getIdUsuario() {
		return this.idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_cargo", nullable = false)
	public Cargos getCargos() {
		return this.cargos;
	}

	public void setCargos(Cargos cargos) {
		this.cargos = cargos;
	}

	@Column(name = "nombre", nullable = false, length = 100)
	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "usuarios")
	public List<Solicitudpresupuesto> getSolicitudpresupuestos() {
		return this.solicitudpresupuestos;
	}

	public void setSolicitudpresupuestos(List<Solicitudpresupuesto> solicitudpresupuestos) {
		this.solicitudpresupuestos = solicitudpresupuestos;
	}

}
