package com.cgi.models;


import java.util.LinkedList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "areas", catalog = "cginversiones")
public class Areas implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idArea;
	private String area;
	private List<Cargos> cargoses = new LinkedList<>();

	public Areas() {
	}

	public Areas(String area) {
		this.area = area;
	}

	public Areas(String area, List<Cargos> cargoses) {
		this.area = area;
		this.cargoses = cargoses;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id_area", unique = true, nullable = false)
	public Integer getIdArea() {
		return this.idArea;
	}

	public void setIdArea(Integer idArea) {
		this.idArea = idArea;
	}

	@Column(name = "area", nullable = false, length = 100)
	public String getArea() {
		return this.area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "areas")
	public List<Cargos> getCargoses() {
		return this.cargoses;
	}

	public void setCargoses(List<Cargos> cargoses) {
		this.cargoses = cargoses;
	}

}
