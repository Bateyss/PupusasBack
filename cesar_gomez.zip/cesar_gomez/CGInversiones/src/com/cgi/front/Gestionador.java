package com.cgi.front;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cgi.impls.AreasImpl;
import com.cgi.impls.BancosImpl;
import com.cgi.impls.CargosImpl;
import com.cgi.impls.ComprobantesImpl;
import com.cgi.impls.CuentasImpl;
import com.cgi.impls.MovimientosImpl;
import com.cgi.impls.SolicitudesImpl;
import com.cgi.impls.UsuariosImpl;
import com.cgi.inc.Conexion;
import com.cgi.models.Solicitudpresupuesto;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.util.JRLoader;

@Controller
@RequestMapping("/")
public class Gestionador {

	@Autowired
	@Qualifier("AreasImpl")
	private AreasImpl areasDao;
	
	@Autowired
	@Qualifier("BancosImpl")
	private BancosImpl bancoasDao;
	
	@Autowired
	@Qualifier("CargosImpl")
	private CargosImpl cargosDao;
	
	@Autowired
	@Qualifier("ComprobantesImpl")
	private ComprobantesImpl comprobantesDao;
	
	@Autowired
	@Qualifier("CuentasImpl")
	private CuentasImpl cuentasDao;
	
	@Autowired
	@Qualifier("MovimientosImpl")
	private MovimientosImpl movimientosDao;
	
	@Autowired
	@Qualifier("SolicitudesImpl")
	private SolicitudesImpl solicitudesDao;
	
	@Autowired
	@Qualifier("UsuariosImpl")
	private UsuariosImpl usuariosDao;
	
	@Autowired
	private HttpServletRequest request;

	@Autowired
	private HttpServletResponse response;
	
	@RequestMapping(value = "/versolicitudes", method = RequestMethod.GET)
	public ModelAndView verSolicitudes() {
		ModelAndView mv = new ModelAndView();
		try {
			List<Solicitudpresupuesto> lista = new LinkedList<>();
			lista = solicitudesDao.findAll();
			// lista.get(0).getIdSolicitud()
			mv.addObject("solicitudes",lista);
		} catch (Exception e) {
			System.out.println("error al ejecutar verSolicitudes en "+ this.getClass().getSimpleName());
		}
		mv.setViewName("solicitudes");
		return mv;
	}
	
	@RequestMapping(value = "/delSolicitud", method = RequestMethod.GET)
	public ModelAndView eliminarSolicitudes(@RequestParam(name = "idSolicitud") int idSolicitud) {
		ModelAndView mv = new ModelAndView();
		try {
			Solicitudpresupuesto s = new Solicitudpresupuesto();
			s.setIdSolicitud(idSolicitud);
			s = solicitudesDao.readById(s.getIdSolicitud());
			solicitudesDao.delete(s);
		} catch (Exception e) {
			System.out.println("error al ejecutar eliminarSolicitudes en "+ this.getClass().getSimpleName());
		}
		mv = verSolicitudes();
		mv.setViewName("solicitudes");
		return mv;
	}
	
	@RequestMapping(value = "/versolicitud", method = RequestMethod.GET)
	public ModelAndView verSolicitud(@RequestParam(name = "idSolicitud") int idSolicitud) {
		ModelAndView mv = new ModelAndView();
		try {
			Solicitudpresupuesto s = new Solicitudpresupuesto();
			s.setIdSolicitud(idSolicitud);
			s = solicitudesDao.readById(s.getIdSolicitud());
			// lista.get(0).getIdSolicitud()
			mv.addObject("solicitud",s);
		} catch (Exception e) {
			System.out.println("error al ejecutar verSolicitudes en "+ this.getClass().getSimpleName());
		}
		mv.setViewName("solicitudes");
		return mv;
	}
	
	@RequestMapping(value = "/jasperVercomprobantes", method = RequestMethod.GET)
	public void generarReporteComprob() {
		try {
			Conexion con = new Conexion(); // se llama una conexion en el caso de que se auto genere el reporte jasper

			JasperReport report = (JasperReport) JRLoader
					.loadObject(request.getServletContext().getRealPath("jasper/comprob.jasper"));

			System.out.println("jaaperreport");
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("title", "cesar");
			JasperPrint jasperPrint = JasperFillManager.fillReport(report, parametros, con.conectar());
			System.out.println("JasperPrint");
			byte[] bytes = JasperRunManager.runReportToPdf(
					request.getServletContext().getRealPath("jasper/comprob.jasper"), parametros, con.conectar());
			response.setContentType("application/pdf");
			response.setContentLength(bytes.length);
			ServletOutputStream os = response.getOutputStream(); // se invoca un output que sera el return del metodo

			os.write(bytes, 0, bytes.length);
			os.flush();
			os.close();

		} catch (Exception e) {
		}
	}
}
