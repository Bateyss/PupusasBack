package com.cgi.utils;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.cgi.impls.AreasImpl;
import com.cgi.impls.BancosImpl;
import com.cgi.impls.CargosImpl;
import com.cgi.impls.ComprobantesImpl;
import com.cgi.impls.CuentasImpl;
import com.cgi.impls.MovimientosImpl;
import com.cgi.impls.SolicitudesImpl;
import com.cgi.impls.UsuariosImpl;

@Configuration
@EnableTransactionManagement(proxyTargetClass = true)
public class RootConfig {
	
	@Bean(name = "AreasImpl")
	public AreasImpl areasDao() {
		return new AreasImpl();
	}
	
	@Bean(name = "BancosImpl")
	public BancosImpl bancosDao() {
		return new BancosImpl();
	}
	
	@Bean(name = "CargosImpl")
	public CargosImpl cargosDao() {
		return new CargosImpl();
	}
	
	@Bean(name = "ComprobantesImpl")
	public ComprobantesImpl comprobantesDao() {
		return new ComprobantesImpl();
	}
	
	@Bean(name = "CuentasImpl")
	public CuentasImpl cuentasDao() {
		return new CuentasImpl();
	}
	@Bean(name = "MovimientosImpl")
	public MovimientosImpl movimientosDao() {
		return new MovimientosImpl();
	}
	
	@Bean(name = "SolicitudesImpl")
	public SolicitudesImpl solicitudesDao() {
		return new SolicitudesImpl();
	}
	
	@Bean(name = "UsuariosImpl")
	public UsuariosImpl usuariosDao() {
		return new UsuariosImpl();
	}

	@Bean
	public DataSource getData() {
		BasicDataSource bds = new BasicDataSource();
		bds.setDriverClassName("com.mysql.jdbc.Driver");
		bds.setUrl("jdbc:mysql://localhost:3306/cginversiones?useSSL=false");
		bds.setUsername("root");
		bds.setPassword("root");
		return bds;
	}
	
	private Properties getProperties() {
		Properties p = new Properties();
		p.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
		return p;
	}
	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sf = new LocalSessionFactoryBean();
		sf.setDataSource(getData());
		sf.setHibernateProperties(getProperties());
		sf.setPackagesToScan("com.cgi.models");
		return sf;
	}
	@Bean
	public PlatformTransactionManager getTransactionManager() {
		HibernateTransactionManager ht = new HibernateTransactionManager();
		ht.setSessionFactory(sessionFactory().getObject());
		return ht;
	}

}
