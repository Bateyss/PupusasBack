package com.cgi.impls;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cgi.inc.AbsInc;
import com.cgi.inc.Dao;
import com.cgi.models.Areas;

@Repository
@Transactional
public class AreasImpl extends AbsInc<Areas> implements Dao<Areas> {

	@Autowired
	private SessionFactory sessionFactory;
	
	public AreasImpl() {
		super(Areas.class);
	}

	@Override
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
