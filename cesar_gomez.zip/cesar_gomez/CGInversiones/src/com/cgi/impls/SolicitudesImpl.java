package com.cgi.impls;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cgi.inc.AbsInc;
import com.cgi.inc.Dao;
import com.cgi.models.Solicitudpresupuesto;

@Repository
@Transactional
public class SolicitudesImpl extends AbsInc<Solicitudpresupuesto> implements Dao<Solicitudpresupuesto> {

	@Autowired
	private SessionFactory sessionFactory;
	
	public SolicitudesImpl() {
		super(Solicitudpresupuesto.class);
	}

	@Override
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
