package com.cgi.impls;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cgi.inc.AbsInc;
import com.cgi.inc.Dao;
import com.cgi.models.Cargos;

@Repository
@Transactional
public class CargosImpl extends AbsInc<Cargos> implements Dao<Cargos> {

	@Autowired
	private SessionFactory sessionFactory;
	
	public CargosImpl() {
		super(Cargos.class);
	}

	@Override
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
