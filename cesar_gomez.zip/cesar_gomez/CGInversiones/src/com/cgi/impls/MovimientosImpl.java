package com.cgi.impls;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cgi.inc.AbsInc;
import com.cgi.inc.Dao;
import com.cgi.models.Movimientos;

@Repository
@Transactional
public class MovimientosImpl extends AbsInc<Movimientos> implements Dao<Movimientos> {

	@Autowired
	private SessionFactory sessionFactory;
	
	public MovimientosImpl() {
		super(Movimientos.class);
	}

	@Override
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
