package com.cgi.impls;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cgi.inc.AbsInc;
import com.cgi.inc.Dao;
import com.cgi.models.Cuentas;

@Repository
@Transactional
public class CuentasImpl extends AbsInc<Cuentas> implements Dao<Cuentas> {

	@Autowired
	private SessionFactory sessionFactory;
	
	public CuentasImpl() {
		super(Cuentas.class);
	}

	@Override
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
