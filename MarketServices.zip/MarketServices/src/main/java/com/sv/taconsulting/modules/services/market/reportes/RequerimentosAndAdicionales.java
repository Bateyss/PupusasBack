package com.sv.taconsulting.modules.services.market.reportes;

import java.io.Serializable;

public class RequerimentosAndAdicionales implements Serializable {

	private static final long serialVersionUID = 4548905126463922833L;
	private Long idSeleccionado;
	private String tipo;
	private String descipcion;
	private String casoUso;
	private String modulo;
	private double precio;
	public static int contador;

	public RequerimentosAndAdicionales() {
		this.idSeleccionado = (long) ++RequerimentosAndAdicionales.contador;
		this.precio = 0.00;
	}

	public RequerimentosAndAdicionales(String tipo, String descipcion, String casoUso,
			String modulo, double precio) {
		this.idSeleccionado = (long) ++RequerimentosAndAdicionales.contador;
		this.tipo = tipo;
		this.descipcion = descipcion;
		this.casoUso = casoUso;
		this.modulo = modulo;
		this.precio = precio;
	}

	public Long getIdSeleccionado() {
		return idSeleccionado;
	}

	public void setIdSeleccionado(Long idSeleccionado) {
		this.idSeleccionado = idSeleccionado;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDescipcion() {
		return descipcion;
	}

	public void setDescipcion(String descipcion) {
		this.descipcion = descipcion;
	}

	public String getCasoUso() {
		return casoUso;
	}

	public void setCasoUso(String casoUso) {
		this.casoUso = casoUso;
	}

	public String getModulo() {
		return modulo;
	}

	public void setModulo(String modulo) {
		this.modulo = modulo;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

}
