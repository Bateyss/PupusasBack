package com.sv.taconsulting.modules.services.market.utils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.springframework.util.Base64Utils;

import com.sun.mail.util.MailSSLSocketFactory;

public class Utilities {

	public static String hashWith256(String textToHash) throws NoSuchAlgorithmException {
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] byteOfTextToHash = textToHash.getBytes(StandardCharsets.UTF_8);
		byte[] hashedByetArray = digest.digest(byteOfTextToHash);
		String encoded = java.util.Base64.getEncoder().encodeToString(hashedByetArray);
		return encoded;
	}

	public static String encrip(String base) {
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(base.getBytes("UTF-8"));
			StringBuffer hexString = new StringBuffer();

			for (int i = 0; i < hash.length; i++) {
				String hex = Integer.toHexString(0xff & hash[i]);
				if (hex.length() == 1)
					hexString.append('0');
				hexString.append(hex);
			}
			return hexString.toString();
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	public static byte[] toPrimitives(Byte[] oBytes) {
		byte[] bytes = new byte[oBytes.length];
		for (int i = 0; i < oBytes.length; i++) {
			bytes[i] = oBytes[i];
		}
		return bytes;
	}

	public static Byte[] toObjects(byte[] bytesPrim) {
		Byte[] bytes = new Byte[bytesPrim.length];
		Arrays.setAll(bytes, n -> bytesPrim[n]);
		return bytes;
	}

	public boolean envioCorreo(String correoTo, String asunto, String mensaje, String mensaje2) {

		try {
			// Propiedades de la conexiÃ³n
			Properties props = new Properties();
//			props.setProperty("mail.smtp.host", "smtp.gmail.com");
//			props.setProperty("mail.smtp.starttls.enable", "true");
//			props.setProperty("mail.smtp.port", "587");
//			props.setProperty("mail.smtp.user", "taconsultingsv@gmail.com");
//			props.setProperty("mail.smtp.auth", "true");
//			props.setProperty("mail.smtp.password", "Consultores1");

			MailSSLSocketFactory sf = new MailSSLSocketFactory();
			sf.setTrustAllHosts(true);

			props.setProperty("mail.smtp.host", "smtp.mail.us-west-2.awsapps.com");
			props.setProperty("mail.smtp.starttls.enable", "false");
			props.setProperty("mail.smtp.port", "465");
			props.put("mail.smtp.ssl.socketFactory", sf);
			props.put("mail.smtp.ssl.enable", "true");
			props.setProperty("mail.smtp.user", "info.consultas@ta-consultingcorp.com");
			props.setProperty("mail.smtp.auth", "true");
			props.setProperty("mail.smtp.password", "2021AlGu0791");

			// Preparamos la sesion
			System.out.println("conectando correo correo !!!!!!");
			// Session session = Session.getDefaultInstance(props);
			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("info.consultas@ta-consultingcorp.com", "2021AlGu0791");
				}
			});
			// Construimos el mensaje
			MimeMessage message = new MimeMessage(session);
			// message.setFrom(new InternetAddress("taconsultingsv@gmail.com"));
			message.setFrom(new InternetAddress("info.consultas@ta-consultingcorp.com"));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(correoTo));
			message.setSubject(asunto);
			message.setText(mensaje + "\n" + mensaje2);
			// Lo enviamos.
			Transport t = session.getTransport("smtp");
			// t.connect("taconsultingsv@gmail.com", "Consultores1");
			t.connect("info.consultas@ta-consultingcorp.com", "2021AlGu0791");
			System.out.println("enviando correo correo !!!!!!");
			t.sendMessage(message, message.getAllRecipients());

			// Cierre.
			t.close();
			System.out.println(("exito " + " Enviado Exitosamente"));

			return true;
		} catch (Exception e) {
			// JSFUtil.setFlashMessage("error", "Error al registrar cuenta");
			System.out.println("Error al enviar mensaje " + e);
			return false;
		}
	}

	public boolean envioCorreoPDF(String correoTo, String asunto, String mensaje, String mensaje2, byte[] pdf) {

		try {
			// Propiedades de la conexiÃ³n
			Properties props = new Properties();
//			props.setProperty("mail.smtp.host", "smtp.gmail.com");
//			props.setProperty("mail.smtp.starttls.enable", "true");
//			props.setProperty("mail.smtp.port", "587");
//			props.setProperty("mail.smtp.user", "taconsultingsv@gmail.com");
//			props.setProperty("mail.smtp.auth", "true");
//			props.setProperty("mail.smtp.password", "Consultores1");

			MailSSLSocketFactory sf = new MailSSLSocketFactory();
			sf.setTrustAllHosts(true);

			props.setProperty("mail.smtp.host", "smtp.mail.us-west-2.awsapps.com");
			props.setProperty("mail.smtp.starttls.enable", "false");
			props.setProperty("mail.smtp.port", "465");
			props.put("mail.smtp.ssl.socketFactory", sf);
			props.put("mail.smtp.ssl.enable", "true");
			props.setProperty("mail.smtp.user", "info.consultas@ta-consultingcorp.com");
			props.setProperty("mail.smtp.auth", "true");
			props.setProperty("mail.smtp.password", "2021AlGu0791");

			// Preparamos la sesion
			System.out.println("conectando correo correo !!!!!!");
			// Session session = Session.getDefaultInstance(props);
			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("info.consultas@ta-consultingcorp.com", "2021AlGu0791");
				}
			});

			// pdf
			MimeBodyPart messageBodyPDF = new MimeBodyPart();
			// messageBodyPDF.setContent(pdf, "application/pdf");
			DataSource dataSrc = new ByteArrayDataSource(pdf, "application/pdf");
			messageBodyPDF.setDataHandler(new DataHandler(dataSrc));
			messageBodyPDF.setFileName("proyecto.pdf");

			// Construimos el mensaje
			MimeMessage message = new MimeMessage(session);
			// message.setFrom(new InternetAddress("taconsultingsv@gmail.com"));
			message.setFrom(new InternetAddress("info.consultas@ta-consultingcorp.com"));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(correoTo));
			message.setSubject(asunto);

			BodyPart messageBodyText = new MimeBodyPart();
			messageBodyText.setText(mensaje + "\n" + mensaje2);

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyText);
			multipart.addBodyPart(messageBodyPDF);

			message.setContent(multipart);

			// Lo enviamos.
			Transport t = session.getTransport("smtp");
			// t.connect("taconsultingsv@gmail.com", "Consultores1");
			t.connect("info.consultas@ta-consultingcorp.com", "2021AlGu0791");
			t.sendMessage(message, message.getAllRecipients());

			// Cierre.
			t.close();
			System.out.println(("exito " + " Enviado Exitosamente"));

			return true;
		} catch (Exception e) {
			// JSFUtil.setFlashMessage("error", "Error al registrar cuenta");
			System.out.println("Error al enviar mensaje " + e);
			return false;
		}
	}

	public static Byte[] base64toByteA(String base64) {
		byte[] decoded = Base64Utils.decodeFromString(base64);
		return toObjects(decoded);
	}

	public static String cByteAtoString(Byte[] content) {
		byte[] decoded = toPrimitives(content);
		String base = Base64Utils.encodeToString(decoded);
		return base;
	}
}
