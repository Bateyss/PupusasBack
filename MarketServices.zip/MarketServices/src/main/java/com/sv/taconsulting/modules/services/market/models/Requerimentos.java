package com.sv.taconsulting.modules.services.market.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "requerimentos")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class Requerimentos implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_requerimento")
	private Long idRequerimento;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_caso")
	private CasosUso casoUso;
	@Column(name = "nombre")
	private String nombre;
	@Column(name = "descripcion")
	private String descripcion;
	@Column(name = "valor")
	private Double valor;

	public Requerimentos() {
	}

	public Requerimentos(Long idRequerimento, CasosUso casoUso, String nombre, String descripcion, Double valor) {
		this.idRequerimento = idRequerimento;
		this.casoUso = casoUso;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.valor = valor;
	}

	public Long getIdRequerimento() {
		return idRequerimento;
	}

	public void setIdRequerimento(Long idRequerimento) {
		this.idRequerimento = idRequerimento;
	}

	public CasosUso getCasoUso() {
		return casoUso;
	}

	public void setCasoUso(CasosUso casoUso) {
		this.casoUso = casoUso;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}
}
