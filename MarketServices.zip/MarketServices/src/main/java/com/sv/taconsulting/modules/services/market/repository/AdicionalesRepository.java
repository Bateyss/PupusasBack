package com.sv.taconsulting.modules.services.market.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sv.taconsulting.modules.services.market.models.Adicionales;

@Repository
public interface AdicionalesRepository extends JpaRepository<Adicionales, Long> {

	@Query(value = "SELECT a FROM Adicionales a WHERE a.casoUsoSeleccionado.appModuloSeleccionado.proyecto.idProyecto = :idProyecto")
	List<Adicionales> findByProyecto(@Param("idProyecto") Long idProyecto);

}
