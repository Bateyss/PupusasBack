package com.sv.taconsulting.modules.services.market.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sv.taconsulting.modules.services.market.models.RequerimentoSeleccioado;

@Repository
public interface RequerimentoSeleccioandoRepository extends JpaRepository<RequerimentoSeleccioado, Long> {
	@Query(value = "SELECT rs FROM RequerimentoSeleccioado rs WHERE rs.casoUsoSeleccionado.appModuloSeleccionado.proyecto.idProyecto = :idProyecto")
	List<RequerimentoSeleccioado> findByProyecto(@Param("idProyecto") Long idProyecto);
}
