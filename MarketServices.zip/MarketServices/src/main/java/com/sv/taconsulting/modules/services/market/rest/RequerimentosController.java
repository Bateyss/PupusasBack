package com.sv.taconsulting.modules.services.market.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sv.taconsulting.modules.services.market.models.Requerimentos;
import com.sv.taconsulting.modules.services.market.repository.RequerimentosRepository;

@RestController
public class RequerimentosController {

	@Autowired
	RequerimentosRepository repository;

	@GetMapping(path = "/requerimentos")
	public ResponseEntity<?> getRequerimento() {
		return new ResponseEntity<List<Requerimentos>>((List<Requerimentos>) repository.findAll(), HttpStatus.OK);
	}

	@GetMapping(path = "/requerimentos/{id}")
	public ResponseEntity<?> getRequerimentoById(@PathVariable Long id) {

		Requerimentos Requerimentos = repository.findById(id).orElse(null);
		if (Requerimentos == null) {
			Map<String, Object> response = new HashMap<>();
			response.put("codigo", 1001);
			response.put("mensaje", "objeto no encontrada.");
			response.put("descripcion",
					"El Objeto con el id ".concat(id.toString()).concat(" no se encontró en la base de datos"));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Requerimentos>(Requerimentos, HttpStatus.OK);
	}

	@PostMapping(path = "/requerimentos")
	public ResponseEntity<?> saveRequerimento(@RequestBody Requerimentos Requerimentos, BindingResult result) {
		if (result.hasErrors()) {
			Map<String, Object> response = new HashMap<>();
			List<HashMap<String, Object>> errors = new ArrayList<>();
			result.getFieldErrors().forEach(err -> {
				Map<String, Object> error = new HashMap<>();
				error.put("campo", err.getField());
				error.put("mensaje", err.getDefaultMessage());
				errors.add((HashMap<String, Object>) error);
			});

			response.put("codigo", 1000);
			response.put("mensaje", "Error de validacion.");
			response.put("errores", errors);
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Requerimentos>(repository.save(Requerimentos), HttpStatus.CREATED);
	}

	@PutMapping(path = "/requerimentos/{id}")
	public ResponseEntity<?> updateRequerimento(@PathVariable Long id, @RequestBody Requerimentos Requerimentos,
			BindingResult result) {
		if (result.hasErrors()) {
			Map<String, Object> response = new HashMap<>();
			List<HashMap<String, Object>> errors = new ArrayList<>();
			result.getFieldErrors().forEach(err -> {
				Map<String, Object> error = new HashMap<>();
				error.put("campo", err.getField());
				error.put("mensaje", err.getDefaultMessage());
				errors.add((HashMap<String, Object>) error);
			});

			response.put("codigo", 1000);
			response.put("mensaje", "Error de validacion.");
			response.put("errores", errors);
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}

		if (repository.findById(id).orElse(null) == null) {
			Map<String, Object> response = new HashMap<>();
			response.put("codigo", 1001);
			response.put("mensaje", "no encontrado.");
			response.put("descripcion",
					"El Objeto con el id ".concat(id.toString()).concat(" no se encontró en la base de datos"));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		Requerimentos.setIdRequerimento(id);
		return new ResponseEntity<Requerimentos>(repository.save(Requerimentos), HttpStatus.OK);
	}

	@DeleteMapping(path = "/requerimentos/{id}")
	public void deleteRequerimento(@PathVariable Long id) {
		repository.deleteById(id);
	}
}
