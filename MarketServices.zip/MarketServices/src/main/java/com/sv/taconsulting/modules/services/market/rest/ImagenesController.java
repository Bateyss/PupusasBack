package com.sv.taconsulting.modules.services.market.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sv.taconsulting.modules.services.market.models.Imagenes;
import com.sv.taconsulting.modules.services.market.repository.ImagenesRepository;

@RestController
public class ImagenesController {

	@Autowired
	ImagenesRepository repository;

	@GetMapping(path = "/imagenes")
	public ResponseEntity<?> getImagen() {
		return new ResponseEntity<List<Imagenes>>((List<Imagenes>) repository.findAll(), HttpStatus.OK);
	}

	@GetMapping(path = "/imagenes/{id}")
	public ResponseEntity<?> getImagenById(@PathVariable Long id) {

		Imagenes Imagenes = repository.findById(id).orElse(null);
		if (Imagenes == null) {
			Map<String, Object> response = new HashMap<>();
			response.put("codigo", 1001);
			response.put("mensaje", "objeto no encontrada.");
			response.put("descripcion",
					"El Objeto con el id ".concat(id.toString()).concat(" no se encontró en la base de datos"));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Imagenes>(Imagenes, HttpStatus.OK);
	}

	@PostMapping(path = "/imagenes")
	public ResponseEntity<?> saveImagen(@RequestBody Imagenes Imagenes, BindingResult result) {
		if (result.hasErrors()) {
			Map<String, Object> response = new HashMap<>();
			List<HashMap<String, Object>> errors = new ArrayList<>();
			result.getFieldErrors().forEach(err -> {
				Map<String, Object> error = new HashMap<>();
				error.put("campo", err.getField());
				error.put("mensaje", err.getDefaultMessage());
				errors.add((HashMap<String, Object>) error);
			});

			response.put("codigo", 1000);
			response.put("mensaje", "Error de validacion.");
			response.put("errores", errors);
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Imagenes>(repository.save(Imagenes), HttpStatus.CREATED);
	}

	@PutMapping(path = "/imagenes/{id}")
	public ResponseEntity<?> updateImagen(@PathVariable Long id, @RequestBody Imagenes Imagenes,
			BindingResult result) {
		if (result.hasErrors()) {
			Map<String, Object> response = new HashMap<>();
			List<HashMap<String, Object>> errors = new ArrayList<>();
			result.getFieldErrors().forEach(err -> {
				Map<String, Object> error = new HashMap<>();
				error.put("campo", err.getField());
				error.put("mensaje", err.getDefaultMessage());
				errors.add((HashMap<String, Object>) error);
			});

			response.put("codigo", 1000);
			response.put("mensaje", "Error de validacion.");
			response.put("errores", errors);
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}

		if (repository.findById(id).orElse(null) == null) {
			Map<String, Object> response = new HashMap<>();
			response.put("codigo", 1001);
			response.put("mensaje", "no encontrado.");
			response.put("descripcion",
					"El Objeto con el id ".concat(id.toString()).concat(" no se encontró en la base de datos"));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		Imagenes.setIdImagen(id);
		return new ResponseEntity<Imagenes>(repository.save(Imagenes), HttpStatus.OK);
	}

	@DeleteMapping(path = "/imagenes/{id}")
	public void deleteImagen(@PathVariable Long id) {
		repository.deleteById(id);
	}
}
