package com.sv.taconsulting.modules.services.market.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "caso_uso_seleccionado")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class CasosUsoSeleccionado implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_casos")
	private Long idCaso;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_modulos")
	private AppModuloSeleccionado appModuloSeleccionado;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_caso")
	private CasosUso casoUso;
	@Column(name = "nombre")
	private String nombre;

	public CasosUsoSeleccionado() {
	}

	public CasosUsoSeleccionado(Long idCaso, AppModuloSeleccionado appModuloSeleccionado, CasosUso casoUso,
			String nombre) {
		super();
		this.idCaso = idCaso;
		this.appModuloSeleccionado = appModuloSeleccionado;
		this.casoUso = casoUso;
		this.nombre = nombre;
	}

	public Long getIdCaso() {
		return idCaso;
	}

	public void setIdCaso(Long idCaso) {
		this.idCaso = idCaso;
	}

	public AppModuloSeleccionado getAppModuloSeleccionado() {
		return appModuloSeleccionado;
	}

	public void setAppModuloSeleccionado(AppModuloSeleccionado appModuloSeleccionado) {
		this.appModuloSeleccionado = appModuloSeleccionado;
	}

	public CasosUso getCasoUso() {
		return casoUso;
	}

	public void setCasoUso(CasosUso casoUso) {
		this.casoUso = casoUso;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
