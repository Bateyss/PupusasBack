/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sv.taconsulting.modules.services.market.reportes;

import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sv.taconsulting.modules.services.market.models.Proyectos;
import com.sv.taconsulting.modules.services.market.utils.Utilities;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

/**
 *
 * @author T420S
 */
public class Reportes {

	public void generarReporteEmail(List<RequerimentosAndAdicionales> datos, String correo, String proyectoUser,
			String proyectoName) {
		try {
			
			//String tt = "src/com/sv/taconsulting/modules/services/market/reportes/reporte.jrxml";
			//System.out.println("file: " + tt);
			//JasperReport report = JasperCompileManager.compileReport(tt);
			
			InputStream im = getClass().getResourceAsStream("/reporte.jrxml");
			JasperReport report = JasperCompileManager.compileReport(im);
			System.out.println("jaaperreport");
			// se invocan parametros para ser insertados en el reporte
			Map<String, Object> parametros = new HashMap<>();
			parametros.put("userName", proyectoUser);
			parametros.put("nameProyect", proyectoName);
			// se adaptan datos para ser insertados al reporte
			DatosJasperAdapter adapter = new DatosJasperAdapter();
			adapter.setLista(datos);
			JasperPrint jasperPrint = JasperFillManager.fillReport(report, parametros, adapter);
			System.out.println("JasperPrint");

			// HttpServletResponse response = (HttpServletResponse)
			// ctx.getExternalContext().getResponse();
			try {
				// ServletOutputStream servletOutputStream = response.getOutputStream();
				// JasperExportManager.exportReportToPdfStream(jasperPrint,
				// servletOutputStream);
				byte[] pdf = JasperExportManager.exportReportToPdf(jasperPrint);
				Utilities t = new Utilities();
				t.envioCorreoPDF(correo, "Su proyecto ha sido resgistrado", "Estimado " + proyectoUser
						+ ". \nEl proyecto " + proyectoName + " ha sido registrado. "
						+ " \nPronto nos comunicaremos para establecer un acuerdo con la fecha y algunos puntos importantes",
						" \nsaluditos..", pdf);
			} catch (JRException err) {
				err.printStackTrace();
			} finally {
				// ctx.responseComplete();
			}

		} catch (Exception e) {
			System.out.println("Error jasper report datos: " + e);
		}
	}

	public void generarReporteEmailGuillermo(Proyectos proyecto) {
		try {
			boolean enviar = true;
//			String tt = ":src/com/sv/taconsulting/modules/services/market/reportes/reporte2.jrxml";
//			ResourceUtils.isUrl(tt);
//			if (ResourceUtils.isUrl(tt)) {
//				System.out.println("url: " + ResourceUtils.getURL(tt));
//				File f = ResourceUtils.getFile(tt);
//				System.out.println("valid single location: " + f.getAbsolutePath());
//				enviar = true;
//			} else {
//				tt = ResourceUtils.getURL("classpath:")
//						+ "com/sv/taconsulting/modules/services/market/reportes/reporte2.jrxml";
//				try {
//					
//					System.out.println("url CLASS: " + getClass().getResource("/reporte2.jrxml").getPath());
//					System.out.println("goin classpath");
//					System.out.println("url: " + ResourceUtils.getURL(tt));
//				} catch (Exception e) {
//					System.out.println("error exxx : " + e);
//				}
//				if (ResourceUtils.isUrl(tt)) {
//					File f = ResourceUtils.getFile(tt);
//					System.out.println("valid classpath location: " + f.getAbsolutePath());
//					enviar = true;
//				} else {
//					tt = System.getProperty("user.dir")
//							+ "/src/main/java/com/sv/taconsulting/modules/services/market/reportes/reporte2.jrxml";
//					System.out.println("goin class absolute path");
//					System.out.println("url: " + ResourceUtils.getURL(tt));
//					if (ResourceUtils.isUrl(tt)) {
//						File f = ResourceUtils.getFile(tt);
//						System.out.println("valid class absolute location: " + f.getAbsolutePath());
//						enviar = true;
//					}
//				}
//			}
			if (proyecto!=null) {
				System.out.println("proyecto getNombreUsuario :"+proyecto.getNombreUsuario());
				System.out.println("proyecto getNombre :"+proyecto.getNombre());
				System.out.println("proyecto getTelefono :"+proyecto.getTelefono());
				System.out.println("proyecto getCorreo :"+proyecto.getCorreo());
				System.out.println("proyecto getDescripcion :"+proyecto.getDescripcion());
				System.out.println("proyecto getPresupuesto :"+proyecto.getPresupuesto());
				System.out.println("proyecto getFechaEntrega :"+proyecto.getFechaEntrega());
				System.out.println("proyecto getAppType().getNombre :"+proyecto.getAppType().getNombre());
				System.out.println("proyecto getAcuerdo :"+proyecto.getAcuerdo());
			}else {
				System.out.println("proyecto is null");
			}
			System.out.println("proyecto :::: "+(proyecto!=null));
			if (enviar && proyecto != null) {
				InputStream im = getClass().getResourceAsStream("/reporte2.jrxml");
				JasperReport report = JasperCompileManager.compileReport(im);
				//JasperReport report = JasperCompileManager.compileReport(tt);
				System.out.println("jaaperreport");
				// se invocan parametros para ser insertados en el reporte
				Map<String, Object> parametros = new HashMap<>();

				SimpleDateFormat spdf = new SimpleDateFormat("dd MMMMM yyyy");
				DecimalFormat df = new DecimalFormat("$ #,##0.00");

				parametros.put("userName", proyecto.getNombreUsuario());
				parametros.put("nameProyect", proyecto.getNombre());
				parametros.put("telefono", proyecto.getTelefono());
				parametros.put("correo", proyecto.getCorreo());
				parametros.put("descripcion", proyecto.getDescripcion());
				parametros.put("presupuesto", df.format(proyecto.getPresupuesto()));
				parametros.put("fechaEntrega", spdf.format(proyecto.getFechaEntrega()));
				parametros.put("tipoProyecto", proyecto.getAppType().getNombre());
				parametros.put("estadoProyecto", proyecto.getAcuerdo());

				// se adaptan datos para ser insertados al reporte
				DatosJasperAdapter adapter = new DatosJasperAdapter();
				RequerimentosAndAdicionales adiciona = new RequerimentosAndAdicionales("", "", "", "", 0.00);
				List<RequerimentosAndAdicionales> lista = new ArrayList<RequerimentosAndAdicionales>();
				lista.add(adiciona);
				adapter.setLista(lista);
				JasperPrint jasperPrint = JasperFillManager.fillReport(report, parametros, adapter);
				System.out.println("JasperPrint");

				try {
					byte[] pdf = JasperExportManager.exportReportToPdf(jasperPrint);
					Utilities t = new Utilities();
					t.envioCorreoPDF("2gbguillermobermudez@gmail.com", "Proyecto Nuevo", "", "\n saluditos..", pdf);
					t.envioCorreoPDF("mg18045@ues.edu.sv", "Proyecto Nuevo", "", "\n saluditos..", pdf);
				} catch (JRException err) {
					err.printStackTrace();
				} finally {
					// ctx.responseComplete();
				}
			}

		} catch (Exception e) {
			System.out.println("Error jasper report datos: " + e);
		}
	}

}
