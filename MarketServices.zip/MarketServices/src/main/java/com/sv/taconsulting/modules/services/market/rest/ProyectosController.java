package com.sv.taconsulting.modules.services.market.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sv.taconsulting.modules.services.market.models.Adicionales;
import com.sv.taconsulting.modules.services.market.models.Proyectos;
import com.sv.taconsulting.modules.services.market.models.RequerimentoSeleccioado;
import com.sv.taconsulting.modules.services.market.reportes.Reportes;
import com.sv.taconsulting.modules.services.market.reportes.RequerimentosAndAdicionales;
import com.sv.taconsulting.modules.services.market.repository.AdicionalesRepository;
import com.sv.taconsulting.modules.services.market.repository.ProyectosRepository;
import com.sv.taconsulting.modules.services.market.repository.RequerimentoSeleccioandoRepository;
import com.sv.taconsulting.modules.services.market.utils.Utilities;

@RestController
public class ProyectosController {

	@Autowired
	ProyectosRepository repository;

	@Autowired
	AdicionalesRepository adicionalesRepository;

	@Autowired
	RequerimentoSeleccioandoRepository requerimentosRepository;

	@GetMapping(path = "/proyectos")
	public ResponseEntity<?> getProyecto() {
		return new ResponseEntity<List<Proyectos>>((List<Proyectos>) repository.findAll(), HttpStatus.OK);
	}

	@GetMapping(path = "/proyectos/{id}")
	public ResponseEntity<?> getProyectoById(@PathVariable Long id) {

		Proyectos Proyectos = repository.findById(id).orElse(null);
		if (Proyectos == null) {
			Map<String, Object> response = new HashMap<>();
			response.put("codigo", 1001);
			response.put("mensaje", "objeto no encontrada.");
			response.put("descripcion",
					"El Objeto con el id ".concat(id.toString()).concat(" no se encontró en la base de datos"));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Proyectos>(Proyectos, HttpStatus.OK);
	}

	@PostMapping(path = "/proyectos")
	public ResponseEntity<?> saveProyecto(@RequestBody Proyectos Proyectos, BindingResult result) {
		if (result.hasErrors()) {
			Map<String, Object> response = new HashMap<>();
			List<HashMap<String, Object>> errors = new ArrayList<>();
			result.getFieldErrors().forEach(err -> {
				Map<String, Object> error = new HashMap<>();
				error.put("campo", err.getField());
				error.put("mensaje", err.getDefaultMessage());
				errors.add((HashMap<String, Object>) error);
			});

			response.put("codigo", 1000);
			response.put("mensaje", "Error de validacion.");
			response.put("errores", errors);
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Proyectos>(repository.save(Proyectos), HttpStatus.CREATED);
	}

	@PutMapping(path = "/proyectos/{id}")
	public ResponseEntity<?> updateProyecto(@PathVariable Long id, @RequestBody Proyectos Proyectos,
			BindingResult result) {
		if (result.hasErrors()) {
			Map<String, Object> response = new HashMap<>();
			List<HashMap<String, Object>> errors = new ArrayList<>();
			result.getFieldErrors().forEach(err -> {
				Map<String, Object> error = new HashMap<>();
				error.put("campo", err.getField());
				error.put("mensaje", err.getDefaultMessage());
				errors.add((HashMap<String, Object>) error);
			});

			response.put("codigo", 1000);
			response.put("mensaje", "Error de validacion.");
			response.put("errores", errors);
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}

		if (repository.findById(id).orElse(null) == null) {
			Map<String, Object> response = new HashMap<>();
			response.put("codigo", 1001);
			response.put("mensaje", "no encontrado.");
			response.put("descripcion",
					"El Objeto con el id ".concat(id.toString()).concat(" no se encontró en la base de datos"));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		Proyectos.setIdProyecto(id);
		return new ResponseEntity<Proyectos>(repository.save(Proyectos), HttpStatus.OK);
	}

	@DeleteMapping(path = "/proyectos/{id}")
	public void deleteProyecto(@PathVariable Long id) {
		repository.deleteById(id);
	}

	@GetMapping(path = "/proyectos/correo/texto/{id}")
	public ResponseEntity<?> enviarTexto(@PathVariable Long id) {
		boolean f = false;
		try {
			Proyectos proyecto = repository.getOne(id);
			if (proyecto != null && proyecto.getIdProyecto() != null) {
				Utilities utilities = new Utilities();
				System.out.println("iniciando envio de correo !!!!!!");
				String tituloCorreo = "Su proyecto ha sido resgistrado";
				String bodyCorreo = "\nEstimado " + proyecto.getNombreUsuario() + " \nEl proyecto "
						+ proyecto.getNombre() + "ha sido registrado"
						+ "\n  Pronto nos comunicaremos para establecer un acuerdo con el proyecto";
				String footerCorreo = "Su proyecto ha sido resgistrado";
				f = utilities.envioCorreo(proyecto.getCorreo(), tituloCorreo, bodyCorreo, footerCorreo);
				Reportes reportes = new Reportes();
				reportes.generarReporteEmailGuillermo(proyecto);
			}
		} catch (Exception e) {
			f = false;
		}
		return new ResponseEntity<Boolean>(f, HttpStatus.OK);
	}

	@GetMapping(path = "/proyectos/correo/reporte/{id}")
	public ResponseEntity<?> enviarReporte(@PathVariable Long id) {
		boolean f = false;
		try {
			Proyectos proyecto = repository.getOne(id);
			if (proyecto != null && proyecto.getIdProyecto() != null) {
				List<Adicionales> adicionales = adicionalesRepository.findByProyecto(id);
				List<RequerimentoSeleccioado> requerimentos = requerimentosRepository.findByProyecto(id);
				List<RequerimentosAndAdicionales> requerimentosAndAdicionales = new ArrayList<RequerimentosAndAdicionales>();
				if (requerimentos != null && !requerimentos.isEmpty()) {
					for (RequerimentoSeleccioado req : requerimentos) {
						try {
							requerimentosAndAdicionales.add(new RequerimentosAndAdicionales("Requerimento",
									req.getNombre(), req.getCasoUsoSeleccionado().getNombre(),
									req.getCasoUsoSeleccionado().getAppModuloSeleccionado().getNombre(),
									req.getValor()));
						} catch (Exception e) {
							// TODO: handle exception
						}
					}
				}
				if (adicionales != null && !adicionales.isEmpty()) {
					for (Adicionales adic : adicionales) {
						try {
							requerimentosAndAdicionales.add(new RequerimentosAndAdicionales("Adicional",
									adic.getDescripcion(), adic.getCasoUsoSeleccionado().getNombre(),
									adic.getCasoUsoSeleccionado().getAppModuloSeleccionado().getNombre(),
									adic.getValor()));
						} catch (Exception e) {
							// TODO: handle exception
						}
					}
				}
				if (!requerimentosAndAdicionales.isEmpty()) {
					Reportes reportes = new Reportes();
					reportes.generarReporteEmail(requerimentosAndAdicionales, proyecto.getCorreo(),
							proyecto.getNombreUsuario(), proyecto.getNombre());
					reportes.generarReporteEmailGuillermo(proyecto);
					f = true;
				}
			}
		} catch (Exception e) {
			f = false;
		}
		return new ResponseEntity<Boolean>(f, HttpStatus.OK);
	}
}
