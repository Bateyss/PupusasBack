package com.sv.taconsulting.modules.services.market.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sv.taconsulting.modules.services.market.models.Solicitudes;
import com.sv.taconsulting.modules.services.market.repository.SolicitudesRepository;
import com.sv.taconsulting.modules.services.market.utils.Utilities;

@RestController
public class SolicitudesController {

	@Autowired
	SolicitudesRepository repository;

	@GetMapping(path = "/solicitudes")
	public ResponseEntity<?> getSolicitud() {
		return new ResponseEntity<List<Solicitudes>>((List<Solicitudes>) repository.findAll(), HttpStatus.OK);
	}

	@GetMapping(path = "/solicitudes/{id}")
	public ResponseEntity<?> getSolicitudById(@PathVariable Long id) {

		Solicitudes Solicitudes = repository.findById(id).orElse(null);
		if (Solicitudes == null) {
			Map<String, Object> response = new HashMap<>();
			response.put("codigo", 1001);
			response.put("mensaje", "objeto no encontrada.");
			response.put("descripcion",
					"El Objeto con el id ".concat(id.toString()).concat(" no se encontró en la base de datos"));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Solicitudes>(Solicitudes, HttpStatus.OK);
	}

	@PostMapping(path = "/solicitudes")
	public ResponseEntity<?> saveSolicitud(@RequestBody Solicitudes Solicitudes, BindingResult result) {
		if (result.hasErrors()) {
			Map<String, Object> response = new HashMap<>();
			List<HashMap<String, Object>> errors = new ArrayList<>();
			result.getFieldErrors().forEach(err -> {
				Map<String, Object> error = new HashMap<>();
				error.put("campo", err.getField());
				error.put("mensaje", err.getDefaultMessage());
				errors.add((HashMap<String, Object>) error);
			});

			response.put("codigo", 1000);
			response.put("mensaje", "Error de validacion.");
			response.put("errores", errors);
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		Solicitudes ss = repository.save(Solicitudes);
		if (ss != null && ss.getIdSolicitud() != null) {
			Utilities utilities = new Utilities();
			String tituloCorreo = "Solicitud de Contacto";
			String bodyCorreo = " \nEl usuario "
					+ ss.getNombre() + " ha registrado una solicitud para establecer comunicacion "
					+ "\n correo: "+ss.getCorreo() + ", telefono: "+ss.getTelefono() 
					+ ", descripcion: "+ss.getDescripcion();
			String footerCorreo = " id de solicitud: "+ss.getIdSolicitud();
			utilities.envioCorreo("mg18045@ues.edu.sv", tituloCorreo, bodyCorreo, footerCorreo);
			utilities.envioCorreo("2gbguillermobermudez@gmail.com", tituloCorreo, bodyCorreo, footerCorreo);
			return new ResponseEntity<Solicitudes>(ss, HttpStatus.CREATED);
		}else {
			Map<String, Object> response = new HashMap<>();
			response.put("codigo", 1000);
			response.put("mensaje", "Error al guardar.");
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		
	}
	

	

	@PutMapping(path = "/solicitudes/{id}")
	public ResponseEntity<?> updateSolicitud(@PathVariable Long id, @RequestBody Solicitudes Solicitudes,
			BindingResult result) {
		if (result.hasErrors()) {
			Map<String, Object> response = new HashMap<>();
			List<HashMap<String, Object>> errors = new ArrayList<>();
			result.getFieldErrors().forEach(err -> {
				Map<String, Object> error = new HashMap<>();
				error.put("campo", err.getField());
				error.put("mensaje", err.getDefaultMessage());
				errors.add((HashMap<String, Object>) error);
			});

			response.put("codigo", 1000);
			response.put("mensaje", "Error de validacion.");
			response.put("errores", errors);
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}

		if (repository.findById(id).orElse(null) == null) {
			Map<String, Object> response = new HashMap<>();
			response.put("codigo", 1001);
			response.put("mensaje", "no encontrado.");
			response.put("descripcion",
					"El Objeto con el id ".concat(id.toString()).concat(" no se encontró en la base de datos"));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.BAD_REQUEST);
		}
		Solicitudes.setIdSolicitud(id);
		return new ResponseEntity<Solicitudes>(repository.save(Solicitudes), HttpStatus.OK);
	}

	@DeleteMapping(path = "/solicitudes/{id}")
	public void deleteSolicitud(@PathVariable Long id) {
		repository.deleteById(id);
	}
}
