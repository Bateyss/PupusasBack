package com.sv.taconsulting.modules.services.market.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "proyectos")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Proyectos implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_proyecto")
	private Long idProyecto;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_tipo")
	private AppTypes appType;
	@Column(name = "nombre")
	private String nombre;
	@Column(name = "nombre_usuario")
	private String nombreUsuario;
	@Column(name = "correo")
	private String correo;
	@Column(name = "telefono")
	private String telefono;
	@Column(name = "descripcion")
	private String descripcion;
	@Column(name = "acuerdo")
	private String acuerdo;
	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_entrega")
	private Date fechaEntrega;
	@Column(name = "presupuesto")
	private Double presupuesto;

	public Proyectos() {
	}

	public Proyectos(Long idProyecto, AppTypes appType, String nombre, String nombreUsuario, String correo,
			String telefono, String descripcion, String acuerdo, Date fechaEntrega, Double presupuesto) {
		super();
		this.idProyecto = idProyecto;
		this.appType = appType;
		this.nombre = nombre;
		this.nombreUsuario = nombreUsuario;
		this.correo = correo;
		this.telefono = telefono;
		this.descripcion = descripcion;
		this.acuerdo = acuerdo;
		this.fechaEntrega = fechaEntrega;
		this.presupuesto = presupuesto;
	}

	public Long getIdProyecto() {
		return idProyecto;
	}

	public void setIdProyecto(Long idProyecto) {
		this.idProyecto = idProyecto;
	}

	public AppTypes getAppType() {
		return appType;
	}

	public void setAppType(AppTypes appType) {
		this.appType = appType;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getAcuerdo() {
		return acuerdo;
	}

	public void setAcuerdo(String acuerdo) {
		this.acuerdo = acuerdo;
	}

	public Date getFechaEntrega() {
		return fechaEntrega;
	}

	public void setFechaEntrega(Date fechaEntrega) {
		this.fechaEntrega = fechaEntrega;
	}

	public Double getPresupuesto() {
		return presupuesto;
	}

	public void setPresupuesto(Double presupuesto) {
		this.presupuesto = presupuesto;
	}

}
