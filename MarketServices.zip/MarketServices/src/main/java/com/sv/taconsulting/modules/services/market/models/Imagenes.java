package com.sv.taconsulting.modules.services.market.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "imagenes")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Imagenes implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_imagen")
	private Long idImagen;
	@Column(name = "nombre")
	private String nombre;
	@Lob
	@Column(name = "contenido")
	private Byte[] contenido;
	public static int contador;

	public Imagenes() {
		super();
	}

	public Imagenes(Long idImagen, String nombre, Byte[] contenido) {
		super();
		this.idImagen = idImagen;
		this.nombre = nombre;
		this.contenido = contenido;
	}

	public Long getIdImagen() {
		return idImagen;
	}

	public void setIdImagen(Long idImagen) {
		this.idImagen = idImagen;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Byte[] getContenido() {
		return contenido;
	}

	public void setContenido(Byte[] contenido) {
		this.contenido = contenido;
	}

}
