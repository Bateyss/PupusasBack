package com.sv.taconsulting.modules.services.market.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "requerimento_seleccionado")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class RequerimentoSeleccioado implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_requerimentos")
	private Long idRequerimento;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_casos")
	private CasosUsoSeleccionado casoUsoSeleccionado;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_requerimento")
	private Requerimentos requerimento;
	@Column(name = "nombre")
	private String nombre;
	@Column(name = "descripcion")
	private String descripcion;
	@Column(name = "valor")
	private Double valor;

	public RequerimentoSeleccioado() {
	}

	public RequerimentoSeleccioado(Long idRequerimento, CasosUsoSeleccionado casoUsoSeleccionado,
			Requerimentos requerimento, String nombre, String descripcion, Double valor) {
		super();
		this.idRequerimento = idRequerimento;
		this.casoUsoSeleccionado = casoUsoSeleccionado;
		this.requerimento = requerimento;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.valor = valor;
	}

	public Long getIdRequerimento() {
		return idRequerimento;
	}

	public void setIdRequerimento(Long idRequerimento) {
		this.idRequerimento = idRequerimento;
	}

	public CasosUsoSeleccionado getCasoUsoSeleccionado() {
		return casoUsoSeleccionado;
	}

	public void setCasoUsoSeleccionado(CasosUsoSeleccionado casoUsoSeleccionado) {
		this.casoUsoSeleccionado = casoUsoSeleccionado;
	}

	public Requerimentos getRequerimento() {
		return requerimento;
	}

	public void setRequerimento(Requerimentos requerimento) {
		this.requerimento = requerimento;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

}
