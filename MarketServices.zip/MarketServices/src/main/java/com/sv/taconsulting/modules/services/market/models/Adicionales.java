package com.sv.taconsulting.modules.services.market.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name = "adicionales")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class Adicionales implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_adicional")
	private Long idAdicional;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_casos")
	private CasosUsoSeleccionado casoUsoSeleccionado;
	@Column(name = "descripcion")
	private String descripcion;
	@Column(name = "valor")
	private Double valor;

	public Adicionales() {
	}

	public Adicionales(Long idAdicional, CasosUsoSeleccionado casoUsoSeleccionado, String descripcion, Double valor) {
		this.idAdicional = idAdicional;
		this.casoUsoSeleccionado = casoUsoSeleccionado;
		this.descripcion = descripcion;
		this.valor = valor;
	}

	public Long getIdAdicional() {
		return idAdicional;
	}

	public void setIdAdicional(Long idAdicional) {
		this.idAdicional = idAdicional;
	}

	public CasosUsoSeleccionado getCasoUsoSeleccionado() {
		return casoUsoSeleccionado;
	}

	public void setCasoUsoSeleccionado(CasosUsoSeleccionado casoUsoSeleccionado) {
		this.casoUsoSeleccionado = casoUsoSeleccionado;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

}
