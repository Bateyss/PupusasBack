package com.sv.taconsulting.modules.services.market.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "app_modulo_seleccionado")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class AppModuloSeleccionado implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_modulos")
	private Long idModulo;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_proyecto")
	private Proyectos proyecto;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_modulo")
	private AppModulos modulo;
	@Column(name = "nombre")
	private String nombre;

	public AppModuloSeleccionado() {
	}

	public AppModuloSeleccionado(Long idModulo, Proyectos proyecto, AppModulos modulo, String nombre) {
		super();
		this.idModulo = idModulo;
		this.proyecto = proyecto;
		this.modulo = modulo;
		this.nombre = nombre;
	}

	public Long getIdModulo() {
		return idModulo;
	}

	public void setIdModulo(Long idModulo) {
		this.idModulo = idModulo;
	}

	public Proyectos getProyecto() {
		return proyecto;
	}

	public void setProyecto(Proyectos proyecto) {
		this.proyecto = proyecto;
	}

	public AppModulos getModulo() {
		return modulo;
	}

	public void setModulo(AppModulos modulo) {
		this.modulo = modulo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
