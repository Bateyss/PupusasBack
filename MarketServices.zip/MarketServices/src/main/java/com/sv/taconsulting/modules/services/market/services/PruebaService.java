package com.sv.taconsulting.modules.services.market.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sv.taconsulting.modules.services.market.models.AppModulos;
import com.sv.taconsulting.modules.services.market.models.AppTypes;
import com.sv.taconsulting.modules.services.market.models.CasosUso;
import com.sv.taconsulting.modules.services.market.models.Requerimentos;
import com.sv.taconsulting.modules.services.market.models.Usuarios;
import com.sv.taconsulting.modules.services.market.repository.AppModulosRepository;
import com.sv.taconsulting.modules.services.market.repository.AppTypesRepository;
import com.sv.taconsulting.modules.services.market.repository.CasosUsoRepository;
import com.sv.taconsulting.modules.services.market.repository.RequerimentosRepository;
import com.sv.taconsulting.modules.services.market.repository.UsuariosRepository;
import com.sv.taconsulting.modules.services.market.utils.Utilities;

@Service
public class PruebaService {

	@Autowired
	private AppTypesRepository appTypesRepository;
	@Autowired
	private AppModulosRepository appModulosRepository;
	@Autowired
	private CasosUsoRepository casosUsoRepository;
	@Autowired
	private RequerimentosRepository requerimentosRepository;
	@Autowired
	private UsuariosRepository usuariosRepository;

	private List<AppTypes> getAppTypes() {
		List<AppTypes> lista = new ArrayList<AppTypes>();
		lista.add(new AppTypes(1L, "Applicacion Web"));
		lista.add(new AppTypes(3L, "Applicacion Android"));
		lista.add(new AppTypes(3L, "Applicacion Escritorio"));
		return lista;
	}

	private List<AppModulos> getAppModulos() {
		List<AppModulos> lista = new ArrayList<AppModulos>();
		List<AppTypes> types = appTypesRepository.findAll();
		lista.add(new AppModulos(1L, types.get(0), "Sesion"));
		lista.add(new AppModulos(2L, types.get(0), "Ventas"));
		lista.add(new AppModulos(3L, types.get(0), "Compras"));
		return lista;
	}

	private List<CasosUso> getCasoUsos() {
		List<CasosUso> lista = new ArrayList<CasosUso>();
		List<AppModulos> modulos = appModulosRepository.findAll();
		lista.add(new CasosUso(1L, modulos.get(0), "Iniciar Sesion", 0.00));
		lista.add(new CasosUso(2L, modulos.get(0), "Crear Usuario", 0.00));
		lista.add(new CasosUso(3L, modulos.get(0), "Recuperacion de Password", 0.00));
		lista.add(new CasosUso(4L, modulos.get(1), "Productos", 0.00));
		lista.add(new CasosUso(5L, modulos.get(2), "Almacen", 0.00));
		return lista;
	}

	private List<Requerimentos> getRequerimentos() {
		List<Requerimentos> lista = new ArrayList<Requerimentos>();
		List<CasosUso> casos = casosUsoRepository.findAll();
		lista.add(new Requerimentos(1L, casos.get(0), "iniciar con correo", "des", 0.00));
		lista.add(new Requerimentos(2L, casos.get(0), "iniciar con redes sociales", "des", 0.00));
		lista.add(new Requerimentos(3L, casos.get(0), "iniciar con nombre de usaurio", "des", 0.00));
		lista.add(new Requerimentos(4L, casos.get(1), "no hay repeticion de correo", "des", 0.00));
		lista.add(new Requerimentos(5L, casos.get(2), "recuperar con el correo", "des", 0.00));
		lista.add(new Requerimentos(6L, casos.get(3), "ver catalogo con precios", "des", 0.00));
		lista.add(new Requerimentos(7L, casos.get(4), "ver inventario de productos", "des", 0.00));
		return lista;
	}

	private List<Usuarios> getUsuarios() {
		List<Usuarios> lista = new ArrayList<Usuarios>();
		lista.add(
				new Usuarios(null, "anonimo", "anonimo", "anonimo@anonimo.com", Utilities.encrip("bateyss"), new Date()));
		lista.add(new Usuarios(null, "cesar", "gomez", "mg18045@ues.edu.sv", Utilities.encrip("bateyss"), new Date()));
		return lista;
	}

	public Boolean datosDePrueba() {
		boolean b = false;
		try {
			for (AppTypes type : getAppTypes()) {
				appTypesRepository.save(type);
			}
			for (AppModulos modulo : getAppModulos()) {
				appModulosRepository.save(modulo);
			}
			for (CasosUso caso : getCasoUsos()) {
				casosUsoRepository.save(caso);
			}
			for (Requerimentos requerimento : getRequerimentos()) {
				requerimentosRepository.save(requerimento);
			}
			for (Usuarios usuario : getUsuarios()) {
				usuariosRepository.save(usuario);
			}
			b = true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return b;
	}

}
