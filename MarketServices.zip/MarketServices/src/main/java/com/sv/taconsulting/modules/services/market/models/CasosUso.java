package com.sv.taconsulting.modules.services.market.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "casos_uso")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class CasosUso implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_caso")
	private Long idCaso;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_modulo")
	private AppModulos appModulo;
	@Column(name = "nombre")
	private String nombre;
	@Column(name = "precio_inicial")
	private Double precioInicial;

	public CasosUso() {
	}

	public CasosUso(Long idCaso, AppModulos appModulo, String nombre, Double precioInicial) {
		this.idCaso = idCaso;
		this.appModulo = appModulo;
		this.nombre = nombre;
		this.precioInicial = precioInicial;
	}

	public Long getIdCaso() {
		return idCaso;
	}

	public void setIdCaso(Long idCaso) {
		this.idCaso = idCaso;
	}

	public AppModulos getAppModulo() {
		return appModulo;
	}

	public void setAppModulo(AppModulos appModulo) {
		this.appModulo = appModulo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Double getPrecioInicial() {
		return precioInicial;
	}

	public void setPrecioInicial(Double precioInicial) {
		this.precioInicial = precioInicial;
	}

}
