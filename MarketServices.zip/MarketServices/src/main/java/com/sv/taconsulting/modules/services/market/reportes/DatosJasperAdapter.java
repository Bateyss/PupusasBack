/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sv.taconsulting.modules.services.market.reportes;

import java.util.ArrayList;
import java.util.List;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

/**
 *
 * @author T420S
 */
public class DatosJasperAdapter implements JRDataSource {

	private List<RequerimentosAndAdicionales> lista = new ArrayList<>();
	private int indice = -1;

	public List<RequerimentosAndAdicionales> getLista() {
		return lista;
	}

	public void setLista(List<RequerimentosAndAdicionales> lista) {
		this.lista = lista;
	}

	@Override
	public boolean next() throws JRException {
		indice++;
		return indice < lista.size();
	}

	@Override
	public Object getFieldValue(JRField jrField) throws JRException {
		Object fieldValue = null;
		if ("tipo".equals(jrField.getName())) {
			fieldValue = this.lista.get(indice).getTipo();
		}
		if ("caso".equals(jrField.getName())) {
			fieldValue = this.lista.get(indice).getCasoUso();
		}
		if ("modulo".equals(jrField.getName())) {
			fieldValue = this.lista.get(indice).getModulo();
		}
		if ("precio".equals(jrField.getName())) {
			fieldValue = this.lista.get(indice).getPrecio();
		}
		if ("descipcion".equals(jrField.getName())) {
			fieldValue = this.lista.get(indice).getDescipcion();
		}
		return fieldValue;
	}

}
