package com.sv.taconsulting.modules.services.market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
